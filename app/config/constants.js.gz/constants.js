export const FIREBASE_API_KEY = "AIzaSyCcS93KU9Rd9PpuO7YlboOuBZzFkN8a8dU";
export const FIREBASE_AUTH_DOMAIN = "mypopularity-d4681.firebaseapp.com";
export const FIREBASE_DATABASE_URL = "https://mypopularity-d4681.firebaseio.com";
export const FIREBASE_PROJECT_ID = "mypopularity-d4681";
export const FIREBASE_STORAGE_BUCKET = "mypopularity-d4681.appspot.com";
export const FIREBASE_MESSAGING_SENDER_ID = "571205797810";

export const FACEBOOK_APP_ID = "176660776366496";